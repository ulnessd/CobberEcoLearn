#!/usr/bin/env python3
"""
CobberEcoSimilar_v1.py

Ecological Similarity Explorer for Chapter 6 of the Ecology ML book.

This app is designed as the ecology analogue of CobberCluster.  It keeps the
same basic rhythm — choose a dataset, choose a similarity question, generate a
matrix — but adapts the pedagogy to ecology:

    * penguins as physical measurement vectors,
    * Portal species as trait/ecological profile vectors,
    * Portal plots as community composition vectors,
    * Portal plot-years as time-filtered community vectors.

Expected data layout, relative to this file or the working directory:

    EcoData/
        Ready/
            penguin_similarity_ready.csv
            portal_species_similarity_ready.csv
            portal_plot_community_ready.csv
            portal_plot_year_community_ready.csv
            portal_species_key_ready.csv
            license_and_citation_notes.txt
            chapter6_data_summary.txt

Run from the project root with:

    python CobberEcoSimilar_v1.py

Dependencies:

    pip install pandas numpy bokeh PyQt6 PyQt6-WebEngine

Notes for packaging:
    This app does not require network access.  It uses local CSV files and
    inline Bokeh resources so the plots render without contacting a CDN.
"""

from __future__ import annotations

import os
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (
    QApplication,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFileDialog,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QStatusBar,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from PyQt6.QtWebEngineCore import QWebEnginePage
from PyQt6.QtWebEngineWidgets import QWebEngineView

from bokeh.embed import file_html
from bokeh.layouts import column, row
from bokeh.models import (
    BasicTicker,
    ColorBar,
    ColumnDataSource,
    CustomJS,
    Div,
    HoverTool,
    LinearColorMapper,
    TapTool,
)
from bokeh.palettes import Category10, Category20, Viridis256
from bokeh.plotting import figure
from bokeh.resources import INLINE


APP_TITLE = "CobberEcoSimilar"


# ---------------------------------------------------------------------
# Feature labels and mode definitions
# ---------------------------------------------------------------------

FEATURE_LABELS: Dict[str, str] = {
    # Penguins
    "bill_length_mm": "Bill length (mm)",
    "bill_depth_mm": "Bill depth (mm)",
    "flipper_length_mm": "Flipper length (mm)",
    "body_mass_g": "Body mass (g)",
    # Portal species
    "observations": "Observation count",
    "log_observations": "Log observation count",
    "weight_records": "Weight records",
    "hindfoot_records": "Hindfoot records",
    "mean_weight_g": "Mean weight (g)",
    "median_weight_g": "Median weight (g)",
    "mean_hindfoot_length_mm": "Mean hindfoot length (mm)",
    "median_hindfoot_length_mm": "Median hindfoot length (mm)",
    "female_fraction": "Female fraction",
    "n_plots_observed": "Number of plots observed",
    "n_plot_types_observed": "Number of plot types observed",
    "n_years_observed": "Number of years observed",
    "seasonal_spread_months": "Seasonal spread (months)",
    "peak_month": "Peak month",
    "frac_plot_type_control": "Fraction in Control plots",
    "frac_plot_type_long_term_krat_exclosure": "Fraction in long-term krat exclosures",
    "frac_plot_type_rodent_exclosure": "Fraction in rodent exclosures",
    "frac_plot_type_short_term_krat_exclosure": "Fraction in short-term krat exclosures",
    "frac_plot_type_spectab_exclosure": "Fraction in Spectab exclosures",
    # Portal communities
    "total_captures": "Total captures",
    "species_richness": "Species richness",
    "shannon_diversity": "Shannon diversity",
}

COUNT_NAME_HINTS: Dict[str, str] = {
    "count_dm": "Dipodomys merriami",
    "count_pp": "Chaetodipus penicillatus",
    "count_do": "Dipodomys ordii",
    "count_pb": "Chaetodipus baileyi",
    "count_rm": "Reithrodontomys megalotis",
    "count_ds": "Dipodomys spectabilis",
    "count_ot": "Onychomys torridus",
    "count_pf": "Perognathus flavus",
    "count_pe": "Peromyscus eremicus",
    "count_nl": "Neotoma albigula",
    "count_ol": "Onychomys leucogaster",
    "count_pm": "Peromyscus maniculatus",
}

PENGUIN_FEATURE_PRESETS = {
    "All physical traits": [
        "bill_length_mm",
        "bill_depth_mm",
        "flipper_length_mm",
        "body_mass_g",
    ],
    "Bill shape": ["bill_length_mm", "bill_depth_mm"],
    "Body size": ["flipper_length_mm", "body_mass_g"],
    "Mass only": ["body_mass_g"],
}

PORTAL_SPECIES_FEATURE_PRESETS = {
    "Body traits": ["mean_weight_g", "mean_hindfoot_length_mm"],
    "Ecological breadth": [
        "log_observations",
        "n_plots_observed",
        "n_plot_types_observed",
        "n_years_observed",
        "seasonal_spread_months",
    ],
    "Habitat / treatment use": [
        "frac_plot_type_control",
        "frac_plot_type_long_term_krat_exclosure",
        "frac_plot_type_rodent_exclosure",
        "frac_plot_type_short_term_krat_exclosure",
        "frac_plot_type_spectab_exclosure",
    ],
    "Full species profile": [
        "mean_weight_g",
        "mean_hindfoot_length_mm",
        "female_fraction",
        "log_observations",
        "n_plots_observed",
        "n_plot_types_observed",
        "n_years_observed",
        "seasonal_spread_months",
        "frac_plot_type_control",
        "frac_plot_type_long_term_krat_exclosure",
        "frac_plot_type_rodent_exclosure",
        "frac_plot_type_short_term_krat_exclosure",
        "frac_plot_type_spectab_exclosure",
    ],
}

COMMUNITY_FEATURE_PRESETS = {
    "Presence / absence (Jaccard)": [],
    "Abundance (Bray-Curtis)": [],
    "Relative abundance profile": [],
    "Summary ecology": ["total_captures", "species_richness", "shannon_diversity"],
}

DATASET_CHOICES = [
    "Palmer Penguins",
    "Portal Species",
    "Portal Plot Communities",
    "Portal Plot-Year Communities",
]

PENGUIN_OBJECT_LEVELS = [
    "Species averages",
    "Species + island averages",
    "Species + sex averages",
    "Individual sample",
]

PORTAL_OBJECT_LEVELS = {
    "Portal Species": ["All prepared species"],
    "Portal Plot Communities": ["All plots"],
    "Portal Plot-Year Communities": ["Plots in selected year"],
}


# ---------------------------------------------------------------------
# Data containers
# ---------------------------------------------------------------------


@dataclass
class PreparedDataset:
    df: pd.DataFrame
    labels: List[str]
    short_labels: List[str]
    groups: List[str]
    metadata_columns: List[str]
    default_features: List[str]
    all_features: List[str]
    title: str
    object_description: str


@dataclass
class SimilarityResult:
    sim: np.ndarray
    embedding: np.ndarray
    method_name: str
    feature_columns: List[str]
    feature_labels: List[str]
    notes: str


@dataclass
class RenderContext:
    prepared: PreparedDataset
    result: SimilarityResult
    focal_index: int


# ---------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------


def app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def candidate_roots() -> List[Path]:
    roots: List[Path] = []
    for p in [Path.cwd(), app_dir(), app_dir().parent, Path.cwd().parent]:
        if p not in roots:
            roots.append(p)
    return roots


def find_ready_dir() -> Optional[Path]:
    for root in candidate_roots():
        for candidate in [
            root / "EcoData" / "Ready",
            root / "Ready",
            root / "DataSets_Models" / "EcoData" / "Ready",
        ]:
            if candidate.exists() and candidate.is_dir():
                return candidate
    return None


def nice_feature_name(col: str) -> str:
    if col in FEATURE_LABELS:
        return FEATURE_LABELS[col]
    if col in COUNT_NAME_HINTS:
        return f"{COUNT_NAME_HINTS[col]} ({col.replace('count_', '').upper()})"
    if col.startswith("count_"):
        return f"Species count: {col.replace('count_', '').upper()}"
    return col.replace("_", " ").title()


def safe_float(x) -> float:
    try:
        return float(x)
    except Exception:
        return float("nan")


def format_value(x) -> str:
    if pd.isna(x):
        return ""
    if isinstance(x, (int, np.integer)):
        return str(int(x))
    try:
        xf = float(x)
        if abs(xf) >= 1000:
            return f"{xf:,.0f}"
        if abs(xf) >= 10:
            return f"{xf:.2f}"
        return f"{xf:.3f}"
    except Exception:
        return str(x)


def make_unique_short_labels(labels: Sequence[str], preferred: Optional[Sequence[str]] = None) -> List[str]:
    if preferred is None:
        preferred = labels
    seen: Dict[str, int] = {}
    out: List[str] = []
    for item in preferred:
        base = str(item)
        if len(base) > 22:
            base = base[:19] + "..."
        if base not in seen:
            seen[base] = 1
            out.append(base)
        else:
            seen[base] += 1
            out.append(f"{base}_{seen[base]}")
    return out


def color_cycle(n: int) -> List[str]:
    if n <= 10:
        return list(Category10[10])
    return list(Category20[20])


def group_colors(groups: Sequence[str]) -> List[str]:
    unique = list(dict.fromkeys(str(g) for g in groups))
    palette = color_cycle(len(unique))
    mapping = {g: palette[i % len(palette)] for i, g in enumerate(unique)}
    return [mapping[str(g)] for g in groups]


# ---------------------------------------------------------------------
# Data manager
# ---------------------------------------------------------------------


class EcoDataManager:
    def __init__(self, ready_dir: Optional[Path] = None):
        self.ready_dir = ready_dir or find_ready_dir()
        self._cache: Dict[str, pd.DataFrame] = {}

    def set_ready_dir(self, ready_dir: Path) -> None:
        self.ready_dir = ready_dir
        self._cache.clear()

    def require_ready_dir(self) -> Path:
        if self.ready_dir is None:
            raise FileNotFoundError(
                "Could not find EcoData/Ready. Use File > Choose Ready Data Folder, "
                "or run this app from the CobberEcoSim project root."
            )
        return self.ready_dir

    def read_csv(self, filename: str) -> pd.DataFrame:
        if filename in self._cache:
            return self._cache[filename].copy()
        path = self.require_ready_dir() / filename
        if not path.exists():
            raise FileNotFoundError(f"Missing required data file: {path}")
        df = pd.read_csv(path)
        self._cache[filename] = df.copy()
        return df

    def read_text_if_exists(self, filename: str) -> str:
        try:
            path = self.require_ready_dir() / filename
        except FileNotFoundError:
            return ""
        if path.exists():
            return path.read_text(encoding="utf-8", errors="replace")
        return ""

    def year_values(self) -> List[int]:
        df = self.read_csv("portal_plot_year_community_ready.csv")
        years = pd.to_numeric(df["year"], errors="coerce").dropna().astype(int).unique()
        return sorted(years.tolist())

    def community_count_columns(self, df: pd.DataFrame) -> List[str]:
        return [c for c in df.columns if c.startswith("count_")]

    def prepare_penguins(self, object_level: str, sample_size: int) -> PreparedDataset:
        raw = self.read_csv("penguin_similarity_ready.csv")
        numeric = ["bill_length_mm", "bill_depth_mm", "flipper_length_mm", "body_mass_g"]

        if object_level == "Species averages":
            gcols = ["species"]
            df = raw.groupby(gcols, dropna=False)[numeric].mean().reset_index()
            df["n_penguins"] = raw.groupby(gcols, dropna=False).size().values
            labels = df["species"].astype(str).tolist()
            short = labels
            groups = labels
            meta = ["species", "n_penguins"]
            desc = "Each row is the average physical profile for one penguin species."

        elif object_level == "Species + island averages":
            gcols = ["species", "island"]
            df = raw.groupby(gcols, dropna=False)[numeric].mean().reset_index()
            df["n_penguins"] = raw.groupby(gcols, dropna=False).size().values
            labels = (df["species"].astype(str) + " on " + df["island"].astype(str)).tolist()
            short = (df["species"].str[:3].astype(str) + "-" + df["island"].str[:3].astype(str)).tolist()
            groups = df["species"].astype(str).tolist()
            meta = ["species", "island", "n_penguins"]
            desc = "Each row is a species-by-island average."

        elif object_level == "Species + sex averages":
            temp = raw[raw["sex"].isin(["male", "female"])].copy()
            gcols = ["species", "sex"]
            df = temp.groupby(gcols, dropna=False)[numeric].mean().reset_index()
            df["n_penguins"] = temp.groupby(gcols, dropna=False).size().values
            labels = (df["species"].astype(str) + " " + df["sex"].astype(str)).tolist()
            short = (df["species"].str[:3].astype(str) + "-" + df["sex"].str[:1].astype(str)).tolist()
            groups = df["species"].astype(str).tolist()
            meta = ["species", "sex", "n_penguins"]
            desc = "Each row is a species-by-sex average."

        else:
            # Fixed random state gives students reproducible results.
            n = max(4, min(int(sample_size), len(raw)))
            df = raw.sample(n=n, random_state=13).sort_values(["species", "penguin_id"]).reset_index(drop=True)
            labels = (df["penguin_id"].astype(str) + " (" + df["species"].astype(str) + ")").tolist()
            short = (df["penguin_id"].astype(str) + " " + df["species"].str[:3].astype(str)).tolist()
            groups = df["species"].astype(str).tolist()
            meta = ["penguin_id", "species", "island", "sex", "year"]
            desc = f"Each row is one penguin from a fixed sample of {n} individuals."

        return PreparedDataset(
            df=df.reset_index(drop=True),
            labels=labels,
            short_labels=make_unique_short_labels(labels, short),
            groups=groups,
            metadata_columns=meta,
            default_features=PENGUIN_FEATURE_PRESETS["All physical traits"],
            all_features=numeric,
            title="Palmer Penguins: physical similarity",
            object_description=desc,
        )

    def prepare_portal_species(self) -> PreparedDataset:
        df = self.read_csv("portal_species_similarity_ready.csv")
        df = df.copy()
        if "log_observations" not in df.columns and "observations" in df.columns:
            df["log_observations"] = np.log10(pd.to_numeric(df["observations"], errors="coerce") + 1.0)

        labels = (df["species_id"].astype(str) + ": " + df["species_name"].astype(str)).tolist()
        short = df["species_id"].astype(str).tolist()
        groups = df.get("genus", pd.Series(["Portal species"] * len(df))).astype(str).tolist()
        meta = [
            "species_id",
            "species_name",
            "genus",
            "species",
            "taxa",
            "observations",
            "first_year_observed",
            "last_year_observed",
        ]
        all_features = sorted(
            set(sum(PORTAL_SPECIES_FEATURE_PRESETS.values(), [])),
            key=sum(PORTAL_SPECIES_FEATURE_PRESETS.values(), []).index,
        )
        all_features = [c for c in all_features if c in df.columns]

        return PreparedDataset(
            df=df.reset_index(drop=True),
            labels=labels,
            short_labels=make_unique_short_labels(labels, short),
            groups=groups,
            metadata_columns=[c for c in meta if c in df.columns],
            default_features=[c for c in PORTAL_SPECIES_FEATURE_PRESETS["Body traits"] if c in df.columns],
            all_features=all_features,
            title="Portal Species: trait and ecological similarity",
            object_description="Each row is a species-level summary derived from Portal Project teaching data.",
        )

    def prepare_portal_plots(self) -> PreparedDataset:
        df = self.read_csv("portal_plot_community_ready.csv")
        return self._prepare_portal_community_common(
            df=df,
            title="Portal Plots: community similarity",
            object_description="Each row is a Portal plot summarized by small-mammal community counts.",
            include_year=False,
        )

    def prepare_portal_plot_years(self, year: int) -> PreparedDataset:
        df = self.read_csv("portal_plot_year_community_ready.csv")
        df["year"] = pd.to_numeric(df["year"], errors="coerce").astype("Int64")
        df = df[df["year"] == int(year)].copy()
        if df.empty:
            raise ValueError(f"No Portal plot-year rows found for year {year}.")
        return self._prepare_portal_community_common(
            df=df,
            title=f"Portal Plot-Year Communities: {year}",
            object_description=f"Each row is one Portal plot in {year}.",
            include_year=True,
        )

    def _prepare_portal_community_common(
        self,
        df: pd.DataFrame,
        title: str,
        object_description: str,
        include_year: bool,
    ) -> PreparedDataset:
        df = df.copy().sort_values("plot_id").reset_index(drop=True)
        count_cols = self.community_count_columns(df)
        labels = ("Plot " + df["plot_id"].astype(str) + " (" + df["plot_type"].astype(str) + ")").tolist()
        if include_year:
            labels = [f"{lab}, {yr}" for lab, yr in zip(labels, df["year"].astype(str))]
        short = [f"P{int(pid)}" for pid in df["plot_id"]]
        if include_year:
            short = [f"{s}-{int(y)}" for s, y in zip(short, df["year"])]
        groups = df["plot_type"].astype(str).tolist()
        meta = ["plot_id", "plot_type", "year", "total_captures", "species_richness", "shannon_diversity"]
        all_features = [c for c in count_cols + ["total_captures", "species_richness", "shannon_diversity"] if c in df.columns]

        return PreparedDataset(
            df=df.reset_index(drop=True),
            labels=labels,
            short_labels=make_unique_short_labels(labels, short),
            groups=groups,
            metadata_columns=[c for c in meta if c in df.columns],
            default_features=count_cols,
            all_features=all_features,
            title=title,
            object_description=object_description,
        )

    def build_prepared(
        self,
        dataset_choice: str,
        object_level: str,
        year: Optional[int],
        sample_size: int,
    ) -> PreparedDataset:
        if dataset_choice == "Palmer Penguins":
            return self.prepare_penguins(object_level, sample_size)
        if dataset_choice == "Portal Species":
            return self.prepare_portal_species()
        if dataset_choice == "Portal Plot Communities":
            return self.prepare_portal_plots()
        if dataset_choice == "Portal Plot-Year Communities":
            if year is None:
                years = self.year_values()
                year = years[0]
            return self.prepare_portal_plot_years(year)
        raise ValueError(f"Unknown dataset choice: {dataset_choice}")


# ---------------------------------------------------------------------
# Similarity engine
# ---------------------------------------------------------------------


class SimilarityEngine:
    @staticmethod
    def numeric_similarity(df: pd.DataFrame, features: Sequence[str]) -> SimilarityResult:
        features = [c for c in features if c in df.columns]
        if not features:
            raise ValueError("No numeric features selected.")

        x = df[features].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=float)

        # Impute any remaining missing values with feature medians.
        med = np.nanmedian(x, axis=0)
        med = np.where(np.isfinite(med), med, 0.0)
        inds = np.where(~np.isfinite(x))
        if len(inds[0]) > 0:
            x[inds] = np.take(med, inds[1])

        means = x.mean(axis=0)
        stds = x.std(axis=0, ddof=0)
        stds = np.where(stds > 1e-12, stds, 1.0)
        z = (x - means) / stds

        dist = pairwise_euclidean(z)
        sim = distance_to_similarity(dist)
        emb = pca_embedding(z)

        return SimilarityResult(
            sim=sim,
            embedding=emb,
            method_name="Standardized Euclidean similarity",
            feature_columns=list(features),
            feature_labels=[nice_feature_name(c) for c in features],
            notes=(
                "The selected measurements were standardized first, so each feature "
                "has equal footing before distance is calculated."
            ),
        )

    @staticmethod
    def jaccard_similarity(df: pd.DataFrame, features: Sequence[str]) -> SimilarityResult:
        features = [c for c in features if c in df.columns and c.startswith("count_")]
        if not features:
            raise ValueError("No species count columns selected for Jaccard similarity.")
        counts = df[features].apply(pd.to_numeric, errors="coerce").fillna(0).to_numpy(dtype=float)
        binary = counts > 0
        n = binary.shape[0]
        sim = np.zeros((n, n), dtype=float)
        for i in range(n):
            for j in range(i, n):
                union = np.logical_or(binary[i], binary[j]).sum()
                inter = np.logical_and(binary[i], binary[j]).sum()
                value = 1.0 if union == 0 else inter / union
                sim[i, j] = sim[j, i] = value
        emb = classical_mds_from_similarity(sim)
        return SimilarityResult(
            sim=sim,
            embedding=emb,
            method_name="Jaccard similarity on presence/absence",
            feature_columns=list(features),
            feature_labels=[nice_feature_name(c) for c in features],
            notes=(
                "Counts were converted to present/absent first. This asks whether two "
                "plots contain the same species, not whether they contain them in the same amounts."
            ),
        )

    @staticmethod
    def bray_curtis_similarity(df: pd.DataFrame, features: Sequence[str]) -> SimilarityResult:
        features = [c for c in features if c in df.columns and c.startswith("count_")]
        if not features:
            raise ValueError("No species count columns selected for Bray-Curtis similarity.")
        x = df[features].apply(pd.to_numeric, errors="coerce").fillna(0).to_numpy(dtype=float)
        n = x.shape[0]
        sim = np.zeros((n, n), dtype=float)
        for i in range(n):
            for j in range(i, n):
                denom = np.sum(x[i] + x[j])
                if denom <= 0:
                    value = 1.0
                else:
                    value = 1.0 - np.sum(np.abs(x[i] - x[j])) / denom
                sim[i, j] = sim[j, i] = max(0.0, min(1.0, value))
        emb = classical_mds_from_similarity(sim)
        return SimilarityResult(
            sim=sim,
            embedding=emb,
            method_name="Bray-Curtis abundance similarity",
            feature_columns=list(features),
            feature_labels=[nice_feature_name(c) for c in features],
            notes=(
                "This uses abundance information. Two plots are similar when the same species "
                "are captured in similar numbers."
            ),
        )

    @staticmethod
    def relative_abundance_similarity(df: pd.DataFrame, features: Sequence[str]) -> SimilarityResult:
        features = [c for c in features if c in df.columns and c.startswith("count_")]
        if not features:
            raise ValueError("No species count columns selected for relative abundance similarity.")
        x = df[features].apply(pd.to_numeric, errors="coerce").fillna(0).to_numpy(dtype=float)
        totals = x.sum(axis=1, keepdims=True)
        totals = np.where(totals > 0, totals, 1.0)
        props = x / totals
        dist = pairwise_euclidean(props)
        sim = distance_to_similarity(dist)
        emb = classical_mds_from_similarity(sim)
        return SimilarityResult(
            sim=sim,
            embedding=emb,
            method_name="Relative abundance profile similarity",
            feature_columns=list(features),
            feature_labels=[nice_feature_name(c) for c in features],
            notes=(
                "Counts were converted to proportions first. This asks whether community "
                "composition is similar after accounting for different total capture numbers."
            ),
        )

    @staticmethod
    def compute(prepared: PreparedDataset, preset_name: str, selected_features: Sequence[str]) -> SimilarityResult:
        if preset_name == "Presence / absence (Jaccard)":
            return SimilarityEngine.jaccard_similarity(prepared.df, selected_features)
        if preset_name == "Abundance (Bray-Curtis)":
            return SimilarityEngine.bray_curtis_similarity(prepared.df, selected_features)
        if preset_name == "Relative abundance profile":
            return SimilarityEngine.relative_abundance_similarity(prepared.df, selected_features)
        return SimilarityEngine.numeric_similarity(prepared.df, selected_features)


# ---------------------------------------------------------------------
# Mathematical helpers
# ---------------------------------------------------------------------


def pairwise_euclidean(x: np.ndarray) -> np.ndarray:
    diff = x[:, None, :] - x[None, :, :]
    return np.sqrt(np.sum(diff * diff, axis=2))


def distance_to_similarity(dist: np.ndarray) -> np.ndarray:
    if dist.size == 0:
        return dist
    max_dist = float(np.nanmax(dist))
    if not np.isfinite(max_dist) or max_dist <= 1e-12:
        return np.ones_like(dist, dtype=float)
    sim = 1.0 - dist / max_dist
    return np.clip(sim, 0.0, 1.0)


def pca_embedding(z: np.ndarray) -> np.ndarray:
    n = z.shape[0]
    if n == 0:
        return np.zeros((0, 2))
    if n == 1:
        return np.zeros((1, 2))
    zc = z - z.mean(axis=0, keepdims=True)
    try:
        u, s, vt = np.linalg.svd(zc, full_matrices=False)
        coords = u[:, :2] * s[:2]
        if coords.shape[1] == 1:
            coords = np.column_stack([coords[:, 0], np.zeros(n)])
        return coords[:, :2]
    except Exception:
        return np.zeros((n, 2))


def classical_mds_from_similarity(sim: np.ndarray) -> np.ndarray:
    n = sim.shape[0]
    if n == 0:
        return np.zeros((0, 2))
    if n == 1:
        return np.zeros((1, 2))

    d = 1.0 - np.clip(sim, 0.0, 1.0)
    d2 = d * d
    j = np.eye(n) - np.ones((n, n)) / n
    b = -0.5 * j @ d2 @ j
    try:
        vals, vecs = np.linalg.eigh(b)
        order = np.argsort(vals)[::-1]
        vals = vals[order]
        vecs = vecs[:, order]
        coords = np.zeros((n, 2))
        for k in range(min(2, n)):
            if vals[k] > 0:
                coords[:, k] = vecs[:, k] * np.sqrt(vals[k])
        return coords
    except Exception:
        return np.zeros((n, 2))


# ---------------------------------------------------------------------
# HTML/Bokeh rendering
# ---------------------------------------------------------------------


def render_dashboard(prepared: PreparedDataset, result: SimilarityResult, focal_index: int) -> str:
    focal_index = max(0, min(focal_index, len(prepared.labels) - 1))

    title_div = Div(
        text=f"""
        <div style="font-family:Lato,Arial,sans-serif;">
          <h1 style="margin-bottom:0.15em;">{APP_TITLE}</h1>
          <h2 style="margin-top:0;color:#6c1d45;">{prepared.title}</h2>
          <p style="font-size:12pt; max-width:1050px;">
            <b>Similarity question:</b> {result.method_name}.<br>
            <b>Objects:</b> {prepared.object_description}<br>
            <b>Features used:</b> {', '.join(result.feature_labels)}
          </p>
          <p style="font-size:11pt; max-width:1050px; color:#333;">
            {result.notes}
          </p>
        </div>
        """,
        sizing_mode="stretch_width",
    )

    heatmap = create_similarity_heatmap(prepared, result)
    scatter = create_embedding_plot(prepared, result)
    neighbor_div = create_neighbor_table(prepared, result, focal_index)
    foot = Div(
        text="""
        <div style="font-family:Lato,Arial,sans-serif;font-size:10pt;color:#555;margin-top:8px;">
        Tip: click a cell in the similarity matrix to compare the two selected objects feature by feature.
        The two-dimensional plot is a projection of the same similarity/feature information; it is meant
        as a guide to pattern, not a replacement for the numerical matrix.
        </div>
        """,
        sizing_mode="stretch_width",
    )

    layout = column(
        title_div,
        row(heatmap, scatter, sizing_mode="stretch_width"),
        neighbor_div,
        foot,
        sizing_mode="stretch_width",
    )
    return file_html(layout, INLINE, APP_TITLE)


def create_similarity_heatmap(prepared: PreparedDataset, result: SimilarityResult):
    sim = result.sim
    labels = prepared.short_labels
    n = len(labels)

    rows = []
    for i in range(n):
        for j in range(n):
            rows.append(
                {
                    "x": labels[j],
                    "y": labels[i],
                    "row_i": i,
                    "col_i": j,
                    "label_a": prepared.labels[i],
                    "label_b": prepared.labels[j],
                    "similarity": sim[i, j],
                }
            )
    source = ColumnDataSource(pd.DataFrame(rows))
    mapper = LinearColorMapper(palette=Viridis256, low=0.0, high=1.0)

    height = min(720, max(430, 22 * n + 180))
    width = min(820, max(500, 20 * n + 230))

    p = figure(
        title="Similarity matrix",
        x_range=labels,
        y_range=list(reversed(labels)),
        tools="pan,wheel_zoom,box_zoom,reset,save",
        toolbar_location="above",
        width=width,
        height=height,
    )
    p.title.text_font_size = "15pt"
    p.rect(
        x="x",
        y="y",
        width=1,
        height=1,
        source=source,
        fill_color={"field": "similarity", "transform": mapper},
        line_color="white",
        line_alpha=0.35,
    )
    p.add_tools(
        HoverTool(
            tooltips=[
                ("Object A", "@label_a"),
                ("Object B", "@label_b"),
                ("Similarity", "@similarity{0.000}"),
            ]
        )
    )
    tap = TapTool()
    p.add_tools(tap)
    p.xaxis.major_label_orientation = 1.1
    p.xaxis.major_label_text_font_size = "9pt" if n <= 24 else "7pt"
    p.yaxis.major_label_text_font_size = "9pt" if n <= 24 else "7pt"
    p.grid.grid_line_color = None
    color_bar = ColorBar(color_mapper=mapper, ticker=BasicTicker(desired_num_ticks=6), label_standoff=8)
    p.add_layout(color_bar, "right")

    cb = CustomJS(
        args=dict(source=source),
        code="""
        const inds = cb_obj.indices;
        if (inds.length > 0) {
            const k = inds[0];
            alert("eco-pair://" + source.data.row_i[k] + "::" + source.data.col_i[k]);
            cb_obj.indices = [];
        }
        """,
    )
    source.selected.js_on_change("indices", cb)
    return p


def create_embedding_plot(prepared: PreparedDataset, result: SimilarityResult):
    coords = result.embedding
    groups = [str(g) for g in prepared.groups]
    colors = group_colors(groups)
    source = ColumnDataSource(
        dict(
            x=coords[:, 0] if len(coords) else [],
            y=coords[:, 1] if len(coords) else [],
            label=prepared.labels,
            short=prepared.short_labels,
            group=groups,
            color=colors,
        )
    )
    p = figure(
        title="Ecological space projection",
        tools="pan,wheel_zoom,box_zoom,reset,save",
        toolbar_location="above",
        width=520,
        height=430,
    )
    p.title.text_font_size = "15pt"
    p.scatter(
        x="x",
        y="y",
        size=11,
        source=source,
        color="color",
        alpha=0.82,
        legend_field="group",
    )
    p.add_tools(
        HoverTool(
            tooltips=[
                ("Object", "@label"),
                ("Group", "@group"),
                ("x", "@x{0.000}"),
                ("y", "@y{0.000}"),
            ]
        )
    )
    p.xaxis.axis_label = "Dimension 1"
    p.yaxis.axis_label = "Dimension 2"
    p.legend.location = "top_right"
    p.legend.click_policy = "hide"
    p.legend.label_text_font_size = "8pt"
    return p


def create_neighbor_table(prepared: PreparedDataset, result: SimilarityResult, focal_index: int):
    sim = result.sim
    focal_label = prepared.labels[focal_index]
    similarities = sim[focal_index].copy()
    order = np.argsort(similarities)[::-1]
    order = [i for i in order if i != focal_index]
    top = order[: min(8, len(order))]

    rows = []
    for rank, i in enumerate(top, start=1):
        meta_bits = []
        for col in prepared.metadata_columns[:4]:
            if col in prepared.df.columns:
                meta_bits.append(f"{nice_feature_name(col)}: {format_value(prepared.df.iloc[i][col])}")
        rows.append(
            f"""
            <tr>
              <td style="text-align:right;">{rank}</td>
              <td>{prepared.labels[i]}</td>
              <td style="text-align:right;">{similarities[i]:0.3f}</td>
              <td>{'; '.join(meta_bits)}</td>
            </tr>
            """
        )

    html = f"""
    <div style="font-family:Lato,Arial,sans-serif; margin-top:12px; max-width:1100px;">
      <h2 style="color:#6c1d45; margin-bottom:0.2em;">Nearest neighbors</h2>
      <p style="font-size:11pt; margin-top:0;">
        <b>Focal object:</b> {focal_label}. These are the most similar objects under the current similarity question.
      </p>
      <table style="border-collapse:collapse; width:100%; font-size:10.5pt;">
        <thead>
          <tr style="background:#6c1d45;color:white;">
            <th style="padding:6px; text-align:right;">Rank</th>
            <th style="padding:6px; text-align:left;">Object</th>
            <th style="padding:6px; text-align:right;">Similarity</th>
            <th style="padding:6px; text-align:left;">Notes</th>
          </tr>
        </thead>
        <tbody>
          {''.join(rows)}
        </tbody>
      </table>
    </div>
    """
    return Div(text=html, sizing_mode="stretch_width")


# ---------------------------------------------------------------------
# Qt dialogs
# ---------------------------------------------------------------------


class PairComparisonDialog(QDialog):
    def __init__(self, context: RenderContext, i: int, j: int, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Pair comparison")
        self.resize(820, 560)
        self.context = context
        self.i = i
        self.j = j
        self._build()

    def _build(self) -> None:
        prepared = self.context.prepared
        result = self.context.result
        df = prepared.df
        sim_value = result.sim[self.i, self.j]

        layout = QVBoxLayout(self)
        header = QLabel(
            f"<b>{prepared.labels[self.i]}</b><br>"
            f"compared with<br>"
            f"<b>{prepared.labels[self.j]}</b><br><br>"
            f"Similarity = <b>{sim_value:0.3f}</b> using {result.method_name}"
        )
        header.setWordWrap(True)
        layout.addWidget(header)

        meta_cols = [c for c in prepared.metadata_columns if c in df.columns]
        if meta_cols:
            meta_box = QGroupBox("Metadata")
            meta_layout = QVBoxLayout(meta_box)
            meta_table = QTableWidget(len(meta_cols), 3)
            meta_table.setHorizontalHeaderLabels(["Field", "Object A", "Object B"])
            for r, col in enumerate(meta_cols):
                meta_table.setItem(r, 0, QTableWidgetItem(nice_feature_name(col)))
                meta_table.setItem(r, 1, QTableWidgetItem(format_value(df.iloc[self.i][col])))
                meta_table.setItem(r, 2, QTableWidgetItem(format_value(df.iloc[self.j][col])))
            meta_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
            meta_table.verticalHeader().setVisible(False)
            meta_layout.addWidget(meta_table)
            layout.addWidget(meta_box)

        feature_cols = [c for c in result.feature_columns if c in df.columns]
        feat_box = QGroupBox("Features used in this similarity calculation")
        feat_layout = QVBoxLayout(feat_box)
        feat_table = QTableWidget(len(feature_cols), 4)
        feat_table.setHorizontalHeaderLabels(["Feature", "Object A", "Object B", "Difference"])
        for r, col in enumerate(feature_cols):
            a = safe_float(df.iloc[self.i][col])
            b = safe_float(df.iloc[self.j][col])
            diff = a - b if np.isfinite(a) and np.isfinite(b) else np.nan
            feat_table.setItem(r, 0, QTableWidgetItem(nice_feature_name(col)))
            feat_table.setItem(r, 1, QTableWidgetItem(format_value(a)))
            feat_table.setItem(r, 2, QTableWidgetItem(format_value(b)))
            feat_table.setItem(r, 3, QTableWidgetItem(format_value(diff)))
        feat_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        feat_table.verticalHeader().setVisible(False)
        feat_layout.addWidget(feat_table)
        layout.addWidget(feat_box)

        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignRight)


class InterceptingPage(QWebEnginePage):
    def __init__(self, parent):
        super().__init__(parent)
        self.main_window = parent

    def javaScriptAlert(self, origin, msg):
        if isinstance(msg, str) and msg.startswith("eco-pair://"):
            try:
                payload = msg.replace("eco-pair://", "")
                a, b = payload.split("::")
                self.main_window.show_pair_comparison(int(a), int(b))
            except Exception as exc:
                QMessageBox.warning(self.main_window, "Pair comparison error", str(exc))
        else:
            super().javaScriptAlert(origin, msg)


# ---------------------------------------------------------------------
# Main GUI
# ---------------------------------------------------------------------


class CobberEcoSimilarApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_TITLE)
        self.resize(1220, 860)
        self.cobber_maroon = QColor(108, 29, 69)
        self.cobber_gold = QColor(234, 170, 0)
        self.setFont(QFont("Lato", 10))

        self.data = EcoDataManager()
        self.current_prepared: Optional[PreparedDataset] = None
        self.current_context: Optional[RenderContext] = None
        self._updating = False

        self._build_menu()
        self._build_ui()
        self.setStatusBar(self._create_status_bar())
        self.refresh_controls()
        self.show_welcome()

    # ----- UI construction -------------------------------------------------

    def _build_menu(self) -> None:
        menu = self.menuBar()
        file_menu = menu.addMenu("File")

        choose_action = file_menu.addAction("Choose Ready Data Folder...")
        choose_action.triggered.connect(self.choose_ready_folder)

        reload_action = file_menu.addAction("Reload Data")
        reload_action.triggered.connect(self.reload_data)

        file_menu.addSeparator()
        quit_action = file_menu.addAction("Quit")
        quit_action.triggered.connect(self.close)

        help_menu = menu.addMenu("Help")
        about_action = help_menu.addAction("About the Data")
        about_action.triggered.connect(self.show_data_notes)
        explain_action = help_menu.addAction("Explain Current Mode")
        explain_action.triggered.connect(self.explain_current_mode)

    def _build_ui(self) -> None:
        central = QWidget()
        main_layout = QVBoxLayout(central)
        main_layout.addWidget(self._create_controls_area())

        self.web = QWebEngineView()
        self.web.setPage(InterceptingPage(self))
        main_layout.addWidget(self.web, stretch=1)
        self.setCentralWidget(central)

    def _create_controls_area(self) -> QWidget:
        wrapper = QFrame()
        wrapper.setFrameShape(QFrame.Shape.StyledPanel)
        wrapper.setStyleSheet(
            "QFrame { background: #fafafa; border: 1px solid #dddddd; } "
            "QGroupBox { font-weight: bold; }"
        )
        layout = QHBoxLayout(wrapper)

        # Left controls
        chooser_box = QGroupBox("Similarity setup")
        grid = QGridLayout(chooser_box)

        self.dataset_combo = QComboBox()
        self.dataset_combo.addItems(DATASET_CHOICES)
        self.dataset_combo.currentTextChanged.connect(self.refresh_controls)

        self.object_combo = QComboBox()
        self.object_combo.currentTextChanged.connect(self.refresh_controls)

        self.preset_combo = QComboBox()
        self.preset_combo.currentTextChanged.connect(self.apply_preset_to_features)

        self.year_combo = QComboBox()
        self.year_combo.currentTextChanged.connect(self.refresh_controls)

        self.sample_spin = QSpinBox()
        self.sample_spin.setRange(8, 60)
        self.sample_spin.setValue(30)
        self.sample_spin.setSingleStep(2)
        self.sample_spin.valueChanged.connect(self.refresh_controls)

        self.focal_combo = QComboBox()

        grid.addWidget(QLabel("Dataset:"), 0, 0)
        grid.addWidget(self.dataset_combo, 0, 1)
        grid.addWidget(QLabel("Object level:"), 1, 0)
        grid.addWidget(self.object_combo, 1, 1)
        grid.addWidget(QLabel("Similarity question:"), 2, 0)
        grid.addWidget(self.preset_combo, 2, 1)
        grid.addWidget(QLabel("Year:"), 3, 0)
        grid.addWidget(self.year_combo, 3, 1)
        grid.addWidget(QLabel("Sample size:"), 4, 0)
        grid.addWidget(self.sample_spin, 4, 1)
        grid.addWidget(QLabel("Focal object:"), 5, 0)
        grid.addWidget(self.focal_combo, 5, 1)

        button_row = QHBoxLayout()
        self.generate_btn = QPushButton("Generate Similarity")
        self.generate_btn.setStyleSheet(
            "QPushButton { font-size: 12pt; padding: 6px 12px; "
            "background-color:#6c1d45; color:white; border-radius:4px; } "
            "QPushButton:disabled { background-color:#999999; }"
        )
        self.generate_btn.clicked.connect(self.generate_similarity)

        self.reset_features_btn = QPushButton("Reset Features")
        self.reset_features_btn.clicked.connect(self.apply_preset_to_features)

        self.explain_btn = QPushButton("Explain")
        self.explain_btn.clicked.connect(self.explain_current_mode)

        button_row.addWidget(self.generate_btn)
        button_row.addWidget(self.reset_features_btn)
        button_row.addWidget(self.explain_btn)
        grid.addLayout(button_row, 6, 0, 1, 2)

        layout.addWidget(chooser_box, stretch=0)

        # Feature list
        feature_box = QGroupBox("Features included")
        feature_layout = QVBoxLayout(feature_box)
        self.feature_list = QListWidget()
        self.feature_list.setMinimumWidth(420)
        self.feature_list.setMaximumHeight(205)
        feature_layout.addWidget(self.feature_list)
        feature_note = QLabel(
            "Check or uncheck features to change what \"similar\" means. "
            "For community modes, the count features are species columns."
        )
        feature_note.setWordWrap(True)
        feature_note.setStyleSheet("color:#555; font-weight:normal;")
        feature_layout.addWidget(feature_note)
        layout.addWidget(feature_box, stretch=1)

        return wrapper

    def _create_status_bar(self) -> QStatusBar:
        bar = QStatusBar()
        if self.data.ready_dir:
            bar.showMessage(f"Ready. Data folder: {self.data.ready_dir}")
        else:
            bar.showMessage("Ready. EcoData/Ready folder not found yet.")
        notes_button = QPushButton("Data Notes")
        notes_button.clicked.connect(self.show_data_notes)
        bar.addPermanentWidget(notes_button)
        return bar

    # ----- control refresh -------------------------------------------------

    def refresh_controls(self) -> None:
        if self._updating:
            return
        self._updating = True
        try:
            dataset = self.dataset_combo.currentText()

            # Object levels.
            old_object = self.object_combo.currentText()
            self.object_combo.blockSignals(True)
            self.object_combo.clear()
            if dataset == "Palmer Penguins":
                self.object_combo.addItems(PENGUIN_OBJECT_LEVELS)
            else:
                self.object_combo.addItems(PORTAL_OBJECT_LEVELS.get(dataset, ["All objects"]))
            if old_object:
                idx = self.object_combo.findText(old_object)
                if idx >= 0:
                    self.object_combo.setCurrentIndex(idx)
            self.object_combo.blockSignals(False)

            # Year selector.
            self.year_combo.blockSignals(True)
            current_year = self.year_combo.currentText()
            self.year_combo.clear()
            if dataset == "Portal Plot-Year Communities":
                try:
                    years = self.data.year_values()
                    self.year_combo.addItems([str(y) for y in years])
                    if current_year:
                        idx = self.year_combo.findText(current_year)
                        if idx >= 0:
                            self.year_combo.setCurrentIndex(idx)
                except Exception:
                    self.year_combo.addItem("Data not found")
                self.year_combo.setEnabled(True)
            else:
                self.year_combo.addItem("Not used")
                self.year_combo.setEnabled(False)
            self.year_combo.blockSignals(False)

            object_level = self.object_combo.currentText()
            self.sample_spin.setEnabled(dataset == "Palmer Penguins" and object_level == "Individual sample")

            # Presets.
            old_preset = self.preset_combo.currentText()
            self.preset_combo.blockSignals(True)
            self.preset_combo.clear()
            if dataset == "Palmer Penguins":
                self.preset_combo.addItems(list(PENGUIN_FEATURE_PRESETS.keys()))
            elif dataset == "Portal Species":
                self.preset_combo.addItems(list(PORTAL_SPECIES_FEATURE_PRESETS.keys()))
            else:
                self.preset_combo.addItems(list(COMMUNITY_FEATURE_PRESETS.keys()))
            if old_preset:
                idx = self.preset_combo.findText(old_preset)
                if idx >= 0:
                    self.preset_combo.setCurrentIndex(idx)
            self.preset_combo.blockSignals(False)

            # Build current prepared dataset for feature and focal lists.
            try:
                self.current_prepared = self.build_current_prepared()
                self.populate_focal_list()
                self.populate_feature_list()
                self.statusBar().showMessage(f"Ready. Data folder: {self.data.ready_dir}")
            except Exception as exc:
                self.current_prepared = None
                self.focal_combo.clear()
                self.feature_list.clear()
                self.statusBar().showMessage(str(exc))
        finally:
            self._updating = False

    def build_current_prepared(self) -> PreparedDataset:
        dataset = self.dataset_combo.currentText()
        object_level = self.object_combo.currentText()
        year = None
        if dataset == "Portal Plot-Year Communities":
            try:
                year = int(self.year_combo.currentText())
            except Exception:
                year = None
        return self.data.build_prepared(
            dataset_choice=dataset,
            object_level=object_level,
            year=year,
            sample_size=self.sample_spin.value(),
        )

    def current_preset_features(self) -> List[str]:
        dataset = self.dataset_combo.currentText()
        preset = self.preset_combo.currentText()
        if dataset == "Palmer Penguins":
            return list(PENGUIN_FEATURE_PRESETS.get(preset, []))
        if dataset == "Portal Species":
            return list(PORTAL_SPECIES_FEATURE_PRESETS.get(preset, []))
        if preset == "Summary ecology":
            return list(COMMUNITY_FEATURE_PRESETS[preset])
        # Community count modes default to all count columns.
        if self.current_prepared:
            return [c for c in self.current_prepared.all_features if c.startswith("count_")]
        return []

    def populate_feature_list(self) -> None:
        self.feature_list.clear()
        if self.current_prepared is None:
            return
        default = set(self.current_preset_features())
        for col in self.current_prepared.all_features:
            item = QListWidgetItem(nice_feature_name(col))
            item.setData(Qt.ItemDataRole.UserRole, col)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Checked if col in default else Qt.CheckState.Unchecked)
            self.feature_list.addItem(item)

    def apply_preset_to_features(self) -> None:
        if self._updating:
            return
        if self.current_prepared is None:
            return
        default = set(self.current_preset_features())
        for r in range(self.feature_list.count()):
            item = self.feature_list.item(r)
            col = item.data(Qt.ItemDataRole.UserRole)
            item.setCheckState(Qt.CheckState.Checked if col in default else Qt.CheckState.Unchecked)

    def populate_focal_list(self) -> None:
        self.focal_combo.clear()
        if self.current_prepared is None:
            return
        self.focal_combo.addItems(self.current_prepared.labels)

    def selected_features(self) -> List[str]:
        selected: List[str] = []
        for r in range(self.feature_list.count()):
            item = self.feature_list.item(r)
            if item.checkState() == Qt.CheckState.Checked:
                selected.append(item.data(Qt.ItemDataRole.UserRole))
        return selected

    # ----- actions ---------------------------------------------------------

    def generate_similarity(self) -> None:
        try:
            prepared = self.build_current_prepared()
            self.current_prepared = prepared
            selected = self.selected_features()
            if not selected:
                raise ValueError("Please select at least one feature.")

            result = SimilarityEngine.compute(prepared, self.preset_combo.currentText(), selected)
            focal_index = self.focal_combo.currentIndex()
            if focal_index < 0:
                focal_index = 0

            self.current_context = RenderContext(prepared=prepared, result=result, focal_index=focal_index)
            self.generate_btn.setEnabled(False)
            self.statusBar().showMessage("Rendering similarity dashboard...")
            html = render_dashboard(prepared, result, focal_index)
            self.web.setHtml(html)
            self.statusBar().showMessage(
                f"Ready. {len(prepared.labels)} objects compared with {len(result.feature_columns)} features."
            )
        except Exception as exc:
            QMessageBox.critical(self, "Could not generate similarity", f"{exc}\n\n{traceback.format_exc()}")
            self.statusBar().showMessage("Error.")
        finally:
            self.generate_btn.setEnabled(True)

    def show_pair_comparison(self, i: int, j: int) -> None:
        if self.current_context is None:
            return
        n = len(self.current_context.prepared.labels)
        if not (0 <= i < n and 0 <= j < n):
            return
        dialog = PairComparisonDialog(self.current_context, i, j, parent=self)
        dialog.exec()

    def choose_ready_folder(self) -> None:
        start = str(self.data.ready_dir or Path.cwd())
        folder = QFileDialog.getExistingDirectory(self, "Choose EcoData/Ready folder", start)
        if folder:
            self.data.set_ready_dir(Path(folder))
            self.refresh_controls()
            self.show_welcome()

    def reload_data(self) -> None:
        self.data._cache.clear()
        self.refresh_controls()
        self.statusBar().showMessage("Data reloaded.")

    def show_data_notes(self) -> None:
        text = self.data.read_text_if_exists("license_and_citation_notes.txt")
        summary = self.data.read_text_if_exists("chapter6_data_summary.txt")
        if not text and not summary:
            text = "No data notes were found. Look for license_and_citation_notes.txt in EcoData/Ready."
        else:
            text = (text + "\n\n" + summary).strip()
        msg = QMessageBox(self)
        msg.setWindowTitle("Chapter 6 Data Notes")
        msg.setText("Dataset notes and preparation summary")
        msg.setDetailedText(text)
        msg.setIcon(QMessageBox.Icon.Information)
        msg.exec()

    def explain_current_mode(self) -> None:
        dataset = self.dataset_combo.currentText()
        preset = self.preset_combo.currentText()
        explanation = explain_mode(dataset, preset)
        QMessageBox.information(self, "Explain this similarity question", explanation)

    def show_welcome(self) -> None:
        ready = self.data.ready_dir
        ready_text = str(ready) if ready else "Not found yet"
        html = f"""
        <html>
          <head>
            <style>
              body {{
                font-family: Lato, Arial, sans-serif;
                background: white;
                margin: 3em;
                color: #222;
              }}
              h1 {{ color: #6c1d45; font-size: 34px; }}
              h2 {{ color: #6c1d45; }}
              .card {{
                border: 1px solid #ddd;
                border-radius: 8px;
                padding: 1.2em;
                max-width: 900px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.08);
              }}
              code {{ background:#f4f4f4; padding:2px 5px; border-radius:3px; }}
            </style>
          </head>
          <body>
            <div class="card">
              <h1>Welcome to {APP_TITLE}</h1>
              <p>
                This app explores ecological similarity using real, prepared teaching datasets.
                Choose a dataset, choose what kind of similarity question you want to ask,
                then click <b>Generate Similarity</b>.
              </p>
              <h2>The central question</h2>
              <p>
                What does it mean for two organisms, plots, or communities to be similar?
                The answer depends on which features you choose. Change the feature set and
                the nearest neighbors may change too.
              </p>
              <h2>Data folder</h2>
              <p><code>{ready_text}</code></p>
              <p>
                Expected files are in <code>EcoData/Ready</code>. If needed, use
                <b>File &gt; Choose Ready Data Folder</b>.
              </p>
            </div>
          </body>
        </html>
        """
        self.web.setHtml(html)


# ---------------------------------------------------------------------
# Text explanations
# ---------------------------------------------------------------------


def explain_mode(dataset: str, preset: str) -> str:
    if dataset == "Palmer Penguins":
        return (
            "Penguin similarity uses physical measurements. The app turns each penguin, "
            "or each group average, into a point in measurement space. Changing from bill "
            "traits to body-size traits changes what counts as similar."
        )
    if dataset == "Portal Species":
        if preset == "Body traits":
            return (
                "Body-trait similarity compares species by mean weight and hindfoot length. "
                "This is a physical definition of similarity."
            )
        if preset == "Ecological breadth":
            return (
                "Ecological-breadth similarity compares species by how widely they appear "
                "across plots, plot types, years, and seasons. This asks whether species are "
                "similar in how broadly they use the study system."
            )
        if preset == "Habitat / treatment use":
            return (
                "Habitat/treatment similarity compares species by the fraction of observations "
                "that occur in each plot treatment type. This asks whether species show up in "
                "similar ecological contexts."
            )
        return (
            "The full species profile combines body traits, breadth, and habitat/treatment use. "
            "This is a deliberately mixed definition of similarity."
        )
    if preset == "Presence / absence (Jaccard)":
        return (
            "Jaccard similarity first converts species counts to present or absent. "
            "Two plots are similar if they contain many of the same species, regardless of abundance."
        )
    if preset == "Abundance (Bray-Curtis)":
        return (
            "Bray-Curtis similarity uses abundance. Two plots are similar when the same species "
            "are found in similar numbers. This is a standard ecological way to compare communities."
        )
    if preset == "Relative abundance profile":
        return (
            "Relative abundance similarity converts counts to proportions first. This reduces "
            "the effect of total capture number and focuses on community composition."
        )
    if preset == "Summary ecology":
        return (
            "Summary ecology ignores individual species identities and compares plots by total "
            "captures, species richness, and Shannon diversity. This can make sites look similar "
            "even when the actual species are different."
        )
    return "This mode compares objects using the selected features."


# ---------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------


def main() -> None:
    app = QApplication(sys.argv)
    win = CobberEcoSimilarApp()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
